package com.multithreading;

public class JoinAndIsAlive implements Runnable{
    String name;
    Thread t;
    public JoinAndIsAlive(String threadName) {
        name = threadName;
        t=new Thread(this, name);
        System.out.println("New Thread:" + t);
    }
    @Override
    public void run() {
        try {
            for(int i=5;i>0;i--){
                System.out.println(name + ": " + i);
                Thread.sleep(1000);
            }
        } catch (InterruptedException e){
            System.out.println(name + "Interrupted");
        }
        System.out.println(name + " exiting");
    }
}
class ThreadDemo4{
    public static void main(String[] args) {
        MultipleThreads t1 = new MultipleThreads("One");
        MultipleThreads t2 = new MultipleThreads("Two");
        MultipleThreads t3 = new MultipleThreads("Three");
        t1.t.start();
        t2.t.start();
        t3.t.start();
        System.out.println("Thread One is alive " + t1.t.isAlive());
        System.out.println("Thread Two is alive " + t2.t.isAlive());
        System.out.println("Thread Three is alive " + t3.t.isAlive());
        //wait for threads to finish
        try{
            Thread.sleep(10000);
        }catch (InterruptedException e){
            System.out.println("Main thread Interrupted");
        }
        System.out.println("Thread One is alive " + t1.t.isAlive());
        System.out.println("Thread Two is alive " + t2.t.isAlive());
        System.out.println("Thread Three is alive " + t3.t.isAlive());
        System.out.println("Main thread existing");
    }


}
