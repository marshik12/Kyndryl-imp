package com.multithreading;

public class DeadlockExample {
    static class Resource{
        //Two resouces that can be locked
        private final Object resource1 = new Object();
        private final Object resource2 = new Object();

        public void method1(){
            synchronized (resource1){
                System.out.println(Thread.currentThread().getName() + " acquired lock on resource1");
                try {
                    Thread.sleep(100);
                }catch (InterruptedException e){
                    e.printStackTrace();
                }
                synchronized (resource2){
                    System.out.println(Thread.currentThread().getName() + " acquired lock on resource2");
                }
            }
        }
        public void method2(){
            synchronized (resource2){
                System.out.println(Thread.currentThread().getName() + " acquired lock on resource2");
                try{
                    Thread.sleep(100);
                }catch (InterruptedException e){
                    e.printStackTrace();
                }
                synchronized (resource1){
                    System.out.println(Thread.currentThread().getName() + " acquired lock on resource1");
                }
            }
        }
    }

    public static void main(String[] args) {
        final Resource resource = new Resource();
        //Thread 1
        Thread t1 = new Thread(()->{
            resource.method1();
        },"Thread-1");

        //Thread 2
        Thread t2 = new Thread(()->{
            resource.method2();
        },"Thread");
        t1.start();
        t2.start();
    }
}
