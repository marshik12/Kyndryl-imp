package com.multithreading;

import java.util.LinkedList;
import java.util.Queue;

public class ProducerAndConsumer {
    private Queue<Integer> queue = new LinkedList<>();
    private static final int MAX_SIZE = 5;

    //Producer adds a msg to queue
    public synchronized void produce(int message){
        while (queue.size() == MAX_SIZE){
            try{
                //Queue is full, wait for consumer to consume
                wait();
            }catch (InterruptedException e){
                Thread.currentThread().interrupt();
            }
        }
        //Add the message to queue
        queue.offer(message);
        System.out.println("Producer: "+ message );
        //Notify consumer that a new message is available
        notify();
    }
    //Consumer removes a message from the queue
    public synchronized int consume(){
        while (queue.isEmpty()){
            try{
                //Queue is empty, wait for the producer to produce
                wait();
            }catch (InterruptedException e){
                Thread.currentThread().interrupt();
            }
        }
        //Remove and return the message from the queue
        int message = queue.poll();
        System.out.println("Consumer: " + message);
        //Notify the producer that space is available in the queue
        notify();
        return message;
    }
}
class Producer implements Runnable{
    private ProducerAndConsumer producerAndConsumer;
    public Producer(ProducerAndConsumer producerAndConsumer){
        this.producerAndConsumer = producerAndConsumer;
    }

    @Override
    public void run() {
        for(int i=0;i<10;i++){
            producerAndConsumer.produce(i);
        }
    }
}
class Consumer implements Runnable{
    private ProducerAndConsumer producerAndConsumer;
    public Consumer(ProducerAndConsumer producerAndConsumer){
        this.producerAndConsumer = producerAndConsumer;
    }

    @Override
    public void run() {
        for(int i=0;i<10;i++){
            producerAndConsumer.consume();
        }
    }
}
class MainThread{
    public static void main(String[] args) {
        ProducerAndConsumer producerAndConsumer = new ProducerAndConsumer();

        Thread producerThread = new Thread(new Producer(producerAndConsumer));
        Thread consumerThread = new Thread(new Consumer(producerAndConsumer));
        producerThread.start();
        consumerThread.start();
    }
}