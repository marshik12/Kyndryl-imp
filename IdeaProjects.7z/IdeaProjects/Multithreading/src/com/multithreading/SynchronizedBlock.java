package com.multithreading;

public class SynchronizedBlock {

    void call(String msg){
        System.out.println("[" + msg);
        try{
            Thread.sleep(1000);
        }catch (InterruptedException e){
            System.out.println("Interrupted");
        }
        System.out.println("]");
    }
}
class Caller1 implements Runnable{
    String msg;
    SynchronizedBlock target;
    Thread t;
    public Caller1(SynchronizedBlock targ, String s){
        target = targ;
        msg = s;
        t = new Thread(this);
    }

    @Override
    public void run() {
        synchronized (target) {
            target.call(msg);
        }
    }
}
class Synch1{
    public static void main(String[] args) {
        SynchronizedBlock target = new SynchronizedBlock();
        Caller1 obj1 = new Caller1(target,"Hello");
        Caller1 obj2 = new Caller1(target,"Synchronized");
        Caller1 obj3 = new Caller1(target,"World");
        obj1.t.start();
        obj2.t.start();
        obj3.t.start();
        try {
            obj1.t.join();
            obj2.t.join();
            obj3.t.join();
        }catch (InterruptedException e){
            System.out.println("Interrupted");
        }
    }
}
