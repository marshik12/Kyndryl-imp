package com.multithreading;

public class ImplementingRunnable implements Runnable {
    /*Thread t;
    ThreadCreationImplementingRunnable(){
        t = new Thread(this,"Demo Thread");
        System.out.println("Child thread: " + t);
    }*/

    @Override
    public void run() {
        try{
            for (int i=5;i>0;i--){
                System.out.println("Child Thread: " + i);
                Thread.sleep(500);
            }
        }catch (InterruptedException e){
            System.out.println("Child interrupted");
        }
        System.out.println("Existing child thread");
    }
}
class ThreadDemo1 {
    public static void main(String[] args) {
        ImplementingRunnable r = new ImplementingRunnable(); //create a new thread
        //nt.t.start(); //start the thread
        Thread t1 = new Thread(r);
        t1.start();
        try{
            for (int j=5;j>0;j--){
                System.out.println("Main Thread: " + j);
                Thread.sleep(1000);
            }
        }catch (InterruptedException e){
            System.out.println("Main thread interrupted");
        }
        System.out.println("Main thread exiting");
    }
}