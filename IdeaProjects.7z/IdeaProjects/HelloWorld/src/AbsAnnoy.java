public class AbsAnnoy {

    public static void main(String[] args) {

        //we can create an object of abstract class by impl annonyms inner class
        C obj1 = new C() {

            public void show() {
                System.out.println("in show()");
            }
        };
        obj1.show();

    }

}

abstract class C{

    public abstract void show();
}