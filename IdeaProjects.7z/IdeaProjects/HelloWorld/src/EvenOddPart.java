import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class EvenOddPart {
    public static void main(String[] args) {
        List<Integer> n = Arrays.asList(1,2,3,4,5,6);
        Map<Boolean, List<Integer>> eo = n.stream().collect(Collectors.partitioningBy(num -> num % 2==0));
      //  System.out.println(eo);
        List<Integer> even = eo.get(true);
        List<Integer> odd = eo.get(false);

        System.out.println("Even :" + even);
        System.out.println("Odd :" + odd);
    }
}
