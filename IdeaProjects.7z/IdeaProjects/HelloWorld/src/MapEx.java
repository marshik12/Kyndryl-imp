import java.util.HashMap;
import java.util.Map;

public class MapEx {
    public static void main(String[] args) {
        Map<Integer,String> m = new HashMap<>();
        m.put(1,"Rajesh");
        m.put(2,"Ram");
        m.put(3,null);

        System.out.println(m.get(3));
    }
}
