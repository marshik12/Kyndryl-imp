package com.demo.lambdaExpression;

interface NumericTest{
    boolean test(int n);
}
public class WithOneParam {
    public static void main(String[] args) {
        NumericTest isEven = (n) -> (n%2)==0;
        if(isEven.test(10)) System.out.println("Even");

        NumericTest isNonNeg = (n) -> n>=0;
        if(isNonNeg.test(-1)) System.out.println("Negative");
    }
}
