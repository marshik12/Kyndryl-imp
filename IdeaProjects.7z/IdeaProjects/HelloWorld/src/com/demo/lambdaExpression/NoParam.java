package com.demo.lambdaExpression;

interface MyNumber{
    double getValue();
}

public class NoParam {
    public static void main(String[] args) {
        MyNumber myNumber = () -> 123.45;
        System.out.println(myNumber.getValue());
        MyNumber myNum = () -> Math.random() * 100;
        System.out.println(myNum.getValue());
        //Lambda expression is not compatible with abstract method
        // Error
        // MyNumber myNum = () -> "123.45";
    }
}
