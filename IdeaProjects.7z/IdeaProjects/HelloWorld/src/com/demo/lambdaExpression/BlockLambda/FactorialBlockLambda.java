package com.demo.lambdaExpression.BlockLambda;

interface Factorial{
    int getFact(int n);
}

public class FactorialBlockLambda {
    public static void main(String[] args) {
        Factorial f = (n) -> {
            int result = 1;
            for (int i=1;i<=n;i++){
                result = result * i;
            }
            return result;
        };
        System.out.println(f.getFact(5));
    }
}
