package com.demo.lambdaExpression.BlockLambda;

interface StringFunc{
    String transform(String str);
}
public class LambdaExpressionArgument {

    static String stringOp(StringFunc sf,String str){
        return sf.transform(str);
    }

    public static void main(String[] args) {
        //Removing space
        String in = "Lambdas Expression as Argument";
        String out = "";
        out = stringOp((str)->{
            String result = "";
            int i;
            for(i=0;i<str.length();i++)
                if(str.charAt(i) != ' ')
                    result += str.charAt(i);
            return result;
        },in);
        System.out.println(out);

        //ReverseString
        String input = "Lambdas Expression as Argument";
        out = stringOp((str)->{
            StringBuilder reversedString = new StringBuilder(str);
            return reversedString.reverse().toString();
        },input);
        System.out.println(out);

        //Passing StringFunc instance created by an earlier lambda expression
        /*StringFunc out = (str) -> {
            String result = "";
            int i;
            for (i = 0; i < str.length(); i++)
                if (str.charAt(i) != ' ')
                    result += str.charAt(i);
            return result;
        };
        System.out.println(stringOp(out,in));
        */
    }
}
