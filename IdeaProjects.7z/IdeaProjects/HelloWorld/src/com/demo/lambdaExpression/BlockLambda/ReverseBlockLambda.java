package com.demo.lambdaExpression.BlockLambda;

interface Reverse{
    String getRev(String str);
}
public class ReverseBlockLambda {
    public static void main(String[] args) {
        Reverse r = (str) ->{
            String rev = "";
            for (int i=str.length()-1;i>=0;i--){
                rev = rev + str.charAt(i);
            }
            return rev;
        };
        System.out.println(r.getRev("Rahul"));
    }

}
