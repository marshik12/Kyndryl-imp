package com.demo.lambdaExpression.BlockLambda;

interface ReverseGen<T>{
    T getGenRev(T t);
}
public class GenericFunctionalInterface {
    public static void main(String[] args) {
        ReverseGen<String> r = (str) ->{
            String genRev = "";

            for (int i=str.length()-1;i>=0;i--){
                genRev = genRev + str.charAt(i);
            }
            return genRev;
        };
        System.out.println(r.getGenRev("Rahul"));
    }

}

