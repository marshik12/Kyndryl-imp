package com.demo.lambdaExpression;

interface NumericTest2{
    boolean test(int n,int d);
}
public class WithTwoParam {
    public static void main(String[] args) {
        NumericTest2 isFactor = (n,d) -> (n%d)==0;
        if(isFactor.test(10,2))
            System.out.println("Factor");
    }


}
