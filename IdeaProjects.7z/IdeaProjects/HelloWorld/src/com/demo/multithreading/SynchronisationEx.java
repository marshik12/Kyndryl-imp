package com.demo.multithreading;

class EvenOdd {
    int num = 1;
    public synchronized void even() {
        while (num % 2 == 1){
                    try {
                        wait();
                    } catch (Exception e) {
                        System.out.println("Exception");
                    }
                }
        System.out.println(Thread.currentThread().getName()+":"+num);
        num++;
                notify();
            }
    public synchronized void odd() {
        while (num % 2 == 0){
                    try {
                        wait();
                    } catch (Exception e) {
                        System.out.println("Exception");
                    }
                }
        System.out.println(Thread.currentThread().getName()+":"+num);
        num++;
                notify();
            }
        }

public class SynchronisationEx {
    public static void main(String[] args) {



        EvenOdd eo = new EvenOdd();

        Thread t1 = new Thread(()->{
            for(int i=0;i<10;i++){
                eo.even();
            }
        },"EvenThread");
        Thread t2 = new Thread(()->{
            for(int i=0;i<10;i++){
                eo.odd();
            }
        },"OddThread");

        t1.start();
        t2.start();
    }
}
