package com.demo.multithreading;

public class ThreadExample implements Runnable{
    Thread t;

    public ThreadExample(String threadName) {
        t=new Thread(this, threadName);
        System.out.println(t);
        t.start();
    }

    synchronized public void newSynchronised(){
        for (int i =0;i<10;i++){
            System.out.println(i + t.getName());
         /*   try {
         //       Thread.sleep(500);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }*/
        }
    }

    @Override
    public void run() {
       newSynchronised();
    }
}
class ThreadRunClass{
    public static void main(String[] args) {
        ThreadExample threadExample = new ThreadExample("One");
        ThreadExample threadExample1 = new ThreadExample("Two");
        ThreadExample threadExample2 = new ThreadExample("Three");

        /*threadExample.t.setPriority(8);
        threadExample1.t.setPriority(3);
        threadExample2.t.setPriority(9);*/

        System.out.println(threadExample.t.isAlive());
        System.out.println(threadExample1.t.isAlive());
        System.out.println(threadExample2.t.isAlive());

        /*try{

            threadExample.t.join();
            threadExample1.t.join();
            threadExample2.t.join();
        }catch (InterruptedException e){
            System.out.println("Main thread interrupted");
        }*/

        System.out.println(threadExample.t.isAlive());
        System.out.println(threadExample1.t.isAlive());
        System.out.println(threadExample2.t.isAlive());
        /*for (int i =0;i<10;i++){
            System.out.println(i + "Main");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }*/
    }
}
