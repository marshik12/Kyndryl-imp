package com.demo;

import java.io.Serializable;

public class Student implements Serializable {

    String sname;
    int rollNum;

    public Student(String sname, int rollNum) {
        this.sname = sname;
        this.rollNum = rollNum;
    }

    public Student() {
    }
}