package com.demo.optional;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class OptionalExample {
    public static void main(String[] args) {
        List<Integer> lists = Arrays.asList(11, 22, 33, 44);

        lists.stream().collect(Collectors.collectingAndThen(Collectors.toList(), list -> {
            Collections.reverse(list);
            return list;
        })).forEach(System.out::println);;

        boolean b = lists.stream().anyMatch(num -> num.equals(Integer.valueOf(33)));
        System.out.println(b);



        Optional<Integer> n = lists.stream().findAny();

    }
}
