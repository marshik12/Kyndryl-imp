package com.demo.streamApi.ShortCircuiting;

import com.demo.flatmap.Employee;
import com.demo.streamApi.terminalOperator.EmployeeNew;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ShortCircuit {
    public static void main(String[] args) {
        CurrentEmployee e1 = new CurrentEmployee(1,"Ramesh");
        CurrentEmployee e2 = new CurrentEmployee(2,"Sam");
        CurrentEmployee e3 = new CurrentEmployee(3,"Rahul");
        CurrentEmployee e4 = new CurrentEmployee(4,"Raghav");

        List<CurrentEmployee> employeeNewList = Arrays.asList(e1,e2,e3,e4);

        //Intermediate Short Circuit operation
        List<CurrentEmployee> currentEmployees = employeeNewList.stream().limit(2).collect(Collectors.toList());
        currentEmployees.forEach(System.out::println);

        //Terminal Short Circuit operation

        //FindFirst() method
        CurrentEmployee currentEmployee = employeeNewList.stream()
                .filter(emp -> emp.getName().contains("Ra")).findFirst().get();
        System.out.println(currentEmployee);

        //FindAny() method
        CurrentEmployee currentEmployee1 = employeeNewList.stream()
                .filter(emp -> emp.getName().contains("Ra")).findAny().get();
        System.out.println(currentEmployee1);

        //AnyMatch() method
        Boolean currentEmployee2 = employeeNewList.stream()
                .anyMatch(emp -> emp.getName().contains("Ra"));
        System.out.println(currentEmployee2);

        //AllMatch() method
        Boolean currentEmployee3 = employeeNewList.stream()
                .allMatch(emp -> emp.getName().contains("Pa"));
        System.out.println(currentEmployee3);

        //AllMatch() method
        Boolean currentEmployee4 = employeeNewList.stream()
                .noneMatch(emp -> emp.getName().contains("Pa"));
        System.out.println(currentEmployee4);
    }
}
