package com.demo.streamApi;

import java.util.Arrays;
import java.util.List;

class Student{
    String name;
    int score;

    public String getName() {
        return name;
    }

    public int getScore() {
        return score;
    }

    public Student(String name, int score) {
        this.name = name;
        this.score = score;
    }
}
public class ParallelStreamVsStream {
    public static void main(String[] args) {
        List<Student> student = Arrays.asList(
                new Student("A",82),
                new Student("B",90),
                new Student("C",65),
                new Student("D",55),
                new Student("E",85),
                new Student("F",88),
                new Student("G",50)
        );

        //using stream() - sequential
        student.stream().filter(s->s.getScore()>=80)
                .limit(3)
                .forEach(stu->System.out.println(stu.getName()+" "+stu.getScore()));

        //parallel stream
        student.parallelStream().filter(s->s.getScore()>=80)
                .limit(3)
                .forEach(stu->System.out.println(stu.getName()+" "+stu.getScore()));

        //convert stream() --> parallelStream
        student.stream().parallel().filter(s->s.getScore()>=80)
                .limit(3)
                .forEach(stu->System.out.println(stu.getName()+" "+stu.getScore()));
    }
}

