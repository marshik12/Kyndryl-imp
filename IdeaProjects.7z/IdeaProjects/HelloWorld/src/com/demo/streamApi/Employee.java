package com.demo.streamApi;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.Arrays.stream;

public class Employee {
    int id;
    String name;
    int age;
    String gender;
    String department;
    int yearOfJoining;
    double salary;
    public Employee(int id, String name, int age, String gender, String department, int yearOfJoining, double salary)
    {
        this.id = id;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.department = department;
        this.yearOfJoining = yearOfJoining;
        this.salary = salary;
    }
    public int getId()
    {
        return id;
    }
    public String getName()
    {
        return name;
    }
    public int getAge()
    {
        return age;
    }
    public String getGender()
    {
        return gender;
    }
    public String getDepartment()
    {
        return department;
    }
    public int getYearOfJoining()
    {
        return yearOfJoining;
    }
    public double getSalary()
    {
        return salary;
    }
    @Override
    public String toString()
    {
        return "Id : "+id
                +", Name : "+name
                +", age : "+age
                +", Gender : "+gender
                +", Department : "+department
                +", Year Of Joining : "+yearOfJoining
                +", Salary : "+salary;
    }
    public static void main(String[] args) {
        List<Employee> employeeList = new ArrayList<Employee>();
        employeeList.add(new Employee(111, "Jiya Brein", 32, "Female", "HR", 2011, 25000.0));
        employeeList.add(new Employee(122, "Paul Niksui", 25, "Male", "Sales And Marketing", 2015, 13500.0));
        employeeList.add(new Employee(133, "Martin Theron", 29, "Male", "Infrastructure", 2012, 18000.0));
        employeeList.add(new Employee(144, "Murali Gowda", 28, "Male", "Product Development", 2014, 32500.0));
        employeeList.add(new Employee(155, "Nima Roy", 27, "Female", "HR", 2013, 22700.0));
        employeeList.add(new Employee(166, "Iqbal Hussain", 43, "Male", "Security And Transport", 2016, 10500.0));
        employeeList.add(new Employee(177, "Manu Sharma", 35, "Male", "Account And Finance", 2010, 27000.0));
        employeeList.add(new Employee(188, "Wang Liu", 31, "Male", "Product Development", 2015, 34500.0));
        employeeList.add(new Employee(199, "Amelia Zoe", 24, "Female", "Sales And Marketing", 2016, 11500.0));
        employeeList.add(new Employee(200, "Jaden Dough", 38, "Male", "Security And Transport", 2015, 11000.5));
        employeeList.add(new Employee(211, "Jasna Kaur", 27, "Female", "Infrastructure", 2014, 15700.0));
        employeeList.add(new Employee(222, "Nitin Joshi", 25, "Male", "Product Development", 2016, 28200.0));
        employeeList.add(new Employee(233, "Jyothi Reddy", 27, "Female", "Account And Finance", 2013, 21300.0));
        employeeList.add(new Employee(244, "Nicolus Den", 24, "Male", "Sales And Marketing", 2017, 10700.5));
        employeeList.add(new Employee(255, "Ali Baig", 23, "Male", "Infrastructure", 2018, 12700.0));
        employeeList.add(new Employee(266, "Sanvi Pandey", 26, "Female", "Product Development", 2015, 28900.0));
        employeeList.add(new Employee(277, "Anuj Chettiar", 31, "Male", "Product Development", 2012, 35700.0));


        //Segregating names based on gender using partitioningby
        Map<Boolean,List<Employee>> ab = employeeList.stream().collect(Collectors.partitioningBy(abc->abc.getGender().equals("Male")));
        List<Employee> emp1 = ab.get(true);
        List<Employee> emp2 = ab.get(false);

        Map<String,List<Employee>> gen = employeeList.stream().collect(Collectors.groupingBy(Employee::getGender));
        System.out.println(gen);

        List<String> name1 = emp1.stream().map(Employee::getName).collect(Collectors.toList());
        List<String> name2 = emp2.stream().map(Employee::getName).collect(Collectors.toList());

        System.out.println("Male" + name1);
        System.out.println("Female " + name2);

        //Counting the male and female employees
        Map<String,Long> m = employeeList.stream().collect(Collectors.groupingBy(Employee::getGender,Collectors.counting()));
        System.out.println(m);

        //Averaging male and female age
        Map<String,Double> avg = employeeList.stream().collect(Collectors.groupingBy((Employee::getGender),Collectors.averagingInt(Employee::getAge)));
        System.out.println(avg);

        //Count the number of employees in each department
        System.out.println(employeeList.stream().collect(Collectors.groupingBy(Employee::getDepartment,Collectors.counting())));

        //Find the employee with the highest salary
        Optional<Employee> highSal = employeeList.stream().max(Comparator.comparingDouble(Employee::getSalary));
        System.out.println(highSal.get());

        //List of female employees
        List<Employee> female = employeeList.stream().filter(f->f.gender.equals("Female")).collect(Collectors.toList());
        female.forEach(System.out::println);

        //Average salary of all employees
        double av = employeeList.stream().mapToDouble(Employee::getSalary).average().orElse(0.0);
        System.out.println(av);

        //Calculate the total salary of all male employees
        //double totSal = employeeList.stream().filter(m->m.gender.equals("Male")).mapToDouble(Employee::getSalary).sum();
       // System.out.println(totSal);

        //Sort employees by year of joining in ascending order
        List<Employee> year = employeeList.stream().sorted(Comparator.comparingInt(Employee::getYearOfJoining)).collect(Collectors.toList());
        year.forEach(System.out::println);

        //Check if there is any employee in the "Security And Transport" department
        boolean dep = employeeList.stream().anyMatch(d->d.department.equals("Security And Transport"));
        System.out.println(dep);

        //Group employees by department and calculate the average salary for each department
        Map<String,Double> depSal = employeeList.stream().collect(Collectors.groupingBy(Employee::getDepartment,Collectors.averagingDouble(Employee::getSalary)));
        System.out.println(depSal);

        //Find the oldest employee
        Optional<Employee> old = employeeList.stream().min(Comparator.comparingInt(Employee::getYearOfJoining));
        System.out.println(old.get().yearOfJoining);

        Integer a[] = {1,2,3,4,5};
        List<Integer> la = Arrays.asList(a);
        System.out.println("Max" +la.stream().max(((o1, o2) -> o2.compareTo(o1))));

        //Second Oldest employee
        Optional<Employee> sold = employeeList.stream().sorted(Comparator.comparingInt(Employee::getYearOfJoining).reversed()).skip(1).findFirst();
        System.out.println(sold.get().getYearOfJoining());

        Optional<Integer> age = employeeList.stream().map(Employee::getYearOfJoining).sorted((o1,o2)->o1.compareTo(o2)).skip(1).findFirst();
        System.out.println("me" + age.get());

        //Name of emp joined after 2015
        List<String> join = employeeList.stream().filter(j->j.yearOfJoining>2015).map(Employee::getName).collect(Collectors.toList());

        //Count number of employee in each department
        System.out.println(employeeList.stream().collect(Collectors.groupingBy(Employee::getDepartment,Collectors.counting())));
    }


}
