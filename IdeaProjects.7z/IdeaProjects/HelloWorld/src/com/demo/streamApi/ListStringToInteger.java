package com.demo.streamApi;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ListStringToInteger {
    public static void main(String[] args) {
        List<String> str = Arrays.asList("1","2","3","4");
        List<Integer> nums = str.stream().map(s -> Integer.parseInt(s)).collect(Collectors.toList());
        nums.forEach(System.out::println);
    }
}
