package com.demo.streamApi;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class DuplicateWithStream {
    public static void main(String[] args) {
        List<Integer> ls = Arrays.asList(5, 13, 4, 21, 13, 27, 2, 59, 59, 34);
        Set<Integer> distinctSet =  new HashSet<>();
        Set<Integer> duplicateSet = ls.stream().filter(l-> !distinctSet.add(l))
                .collect(Collectors.toSet());
        duplicateSet.forEach(System.out::println);


    }
}
