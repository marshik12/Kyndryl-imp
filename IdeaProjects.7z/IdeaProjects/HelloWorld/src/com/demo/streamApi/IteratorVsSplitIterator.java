package com.demo.streamApi;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Spliterator;
import java.util.stream.Stream;

public class IteratorVsSplitIterator {
    public static void main(String[] args) {
        List<String> ls = new ArrayList<>();
        ls.add("Alpha");
        ls.add("Beta");
        ls.add("Gamma");
        ls.add("Delta");
        ls.add("Omega");

        Stream<String> stream = ls.stream();

        //Iterator
        Iterator<String> itr = stream.iterator();
        while (itr.hasNext()){
            System.out.println(itr.next());
        }

        //SplitIterator
        Stream<String> stream2 = ls.stream();
        Spliterator<String> splitItr = stream2.spliterator();
        while(splitItr.tryAdvance((n)->System.out.println(n)));

        //trySplit
        Stream<String> stream3 = ls.stream();
        Spliterator<String> splitItr1 = stream3.spliterator();
        Spliterator<String> splitItr2 = splitItr1.trySplit();
        if(splitItr2 != null){
            splitItr2.forEachRemaining((n)->System.out.println(n));
        }
        splitItr1.forEachRemaining((n)->System.out.println(n));
    }
}
