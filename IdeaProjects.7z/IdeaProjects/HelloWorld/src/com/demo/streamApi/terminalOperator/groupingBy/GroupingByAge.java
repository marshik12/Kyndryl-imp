package com.demo.streamApi.terminalOperator.groupingBy;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class GroupingByAge {
    public static void main(String[] args) {
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee("Ramesh",30));
        employees.add(new Employee("Suresh",35));
        employees.add(new Employee("Raghav",30));
        employees.add(new Employee("Rahul",28));
        employees.add(new Employee("Rishav",30));

        //Grouping By age
        Map<Integer,List<Employee>> m = employees.stream().collect(Collectors.groupingBy(emp -> emp.getAge()));
        System.out.println(m);

        //Get the name of employees whose age is more than 30
        List<String> s = employees.stream().filter(e -> e.getAge() > 28).map(e -> e.getName()).collect(Collectors.toList());
        System.out.println(s);
    }
}
