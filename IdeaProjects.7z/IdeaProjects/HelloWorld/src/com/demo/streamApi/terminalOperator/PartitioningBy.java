package com.demo.streamApi.terminalOperator;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class PartitioningBy {
    public static void main(String[] args) {
        List<Integer> ls = Arrays.asList(30,40,70,80);
        Map<Boolean,List<Integer>> m = ls.stream().collect(Collectors.partitioningBy(n -> n>60));
        List<Integer> gT = m.get(true);
        List<Integer> lT = m.get(false);

        System.out.println(gT);
        System.out.println(lT);
    }
}
