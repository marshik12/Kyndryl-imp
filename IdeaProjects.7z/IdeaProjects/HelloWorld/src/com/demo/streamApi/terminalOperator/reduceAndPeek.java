package com.demo.streamApi.terminalOperator;

import java.util.Arrays;
import java.util.List;

public class reduceAndPeek {
    public static void main(String[] args) {
        EmployeeNew e1 = new EmployeeNew(1,"Ramesh");
        EmployeeNew e2 = new EmployeeNew(2,"Sam");
        EmployeeNew e3 = new EmployeeNew(3,"Rahul");
        EmployeeNew e4 = new EmployeeNew(4,"Raghav");

        List<EmployeeNew> employeeNewList = Arrays.asList(e1,e2,e3,e4);

        List<Integer> integerList = Arrays.asList(1,2,3,4,5);

        //Peek() method
        System.out.println(integerList.stream().filter(a -> a%2 ==0).map(a -> a+a).peek(System.out::println).filter(a -> a>5).count());

        //Reduce() method
        System.out.println(integerList.stream().reduce((a,b) -> a+b).get());


    }
}
