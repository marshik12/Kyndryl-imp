package com.demo.streamApi.terminalOperator;

import java.util.Arrays;
import java.util.List;

public class CountStream {
    public static void main(String[] args) {
        // creating a list of Integers
        Integer i[] = {1,2,3,4,5};
        List<Integer> m = Arrays.asList(i);
        List<Integer> list = Arrays.asList(0, 2, 4, 6, 8, 10, 12);
        long total = list.stream().count();
        System.out.println(total);
    }
}
