package com.demo.streamApi;

import java.util.Arrays;
import java.util.Collection;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class indexOfArrayElement {
    public static void main(String[] args) {
        int[] array = {1,2,3,4,5};
        int search = 2;
        int index = IntStream.range(0,array.length)
                .filter(i -> array[i]==search).findFirst().orElse(-1);
        System.out.println(index);
    }
}
