package com.demo.streamApi;

import java.util.Comparator;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class OptionalMaxByStream {
    public static void main(String[] args) {
        Stream<String> s = Stream.of("2", "3", "4", "5");

        Optional<String> obj = s.collect(Collectors.maxBy(Comparator.reverseOrder()));

        if (obj.isPresent()) {
            System.out.println(obj.get());{

            }
        }
        else {
            System.out.println("no value");
        }
    }
}

