package com.demo.streamApi;

import java.util.*;
import java.util.function.BinaryOperator;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Latest {
    int id;
    String name;
    int age;
    String gender;
    String department;
    int yearOfJoining;
    double salary;
    public Latest(int id, String name, int age, String gender, String department, int yearOfJoining, double salary)
    {
        this.id = id;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.department = department;
        this.yearOfJoining = yearOfJoining;
        this.salary = salary;
    }
    public int getId()
    {
        return id;
    }
    public String getName()
    {
        return name;
    }
    public int getAge()
    {
        return age;
    }
    public String getGender()
    {
        return gender;
    }
    public String getDepartment()
    {
        return department;
    }
    public int getYearOfJoining()
    {
        return yearOfJoining;
    }
    public double getSalary()
    {
        return salary;
    }
    @Override
    public String toString()
    {
        return "Id : "+id
                +", Name : "+name
                +", age : "+age
                +", Gender : "+gender
                +", Department : "+department
                +", Year Of Joining : "+yearOfJoining
                +", Salary : "+salary;
    }
    public static void main(String[] args) {
        List<Latest> employeeList = new ArrayList<Latest>();
        employeeList.add(new Latest(111, "Jiya Brein", 32, "Female", "HR", 2011, 25000.0));
        employeeList.add(new Latest(122, "Paul Niksui", 25, "Male", "Sales And Marketing", 2015, 13500.0));
        employeeList.add(new Latest(133, "Martin Theron", 29, "Male", "Infrastructure", 2012, 18000.0));
        employeeList.add(new Latest(144, "Murali Gowda", 28, "Male", "Product Development", 2014, 32500.0));
        employeeList.add(new Latest(155, "Nima Roy", 27, "Female", "HR", 2013, 22700.0));
        employeeList.add(new Latest(166, "Iqbal Hussain", 43, "Male", "Security And Transport", 2016, 10500.0));
        employeeList.add(new Latest(177, "Manu Sharma", 35, "Male", "Account And Finance", 2010, 27000.0));
        employeeList.add(new Latest(188, "Wang Liu", 31, "Male", "Product Development", 2015, 34500.0));
        employeeList.add(new Latest(199, "Amelia Zoe", 24, "Female", "Sales And Marketing", 2016, 11500.0));
        employeeList.add(new Latest(200, "Jaden Dough", 38, "Male", "Security And Transport", 2015, 11000.5));
        employeeList.add(new Latest(211, "Jasna Kaur", 27, "Female", "Infrastructure", 2014, 15700.0));
        employeeList.add(new Latest(222, "Nitin Joshi", 25, "Male", "Product Development", 2016, 28200.0));
        employeeList.add(new Latest(233, "Jyothi Reddy", 27, "Female", "Account And Finance", 2013, 21300.0));
        employeeList.add(new Latest(244, "Nicolus Den", 24, "Male", "Sales And Marketing", 2017, 10700.5));
        employeeList.add(new Latest(255, "Ali Baig", 23, "Male", "Infrastructure", 2018, 12700.0));
        employeeList.add(new Latest(266, "Sanvi Pandey", 26, "Female", "Product Development", 2015, 28900.0));
        employeeList.add(new Latest(277, "Anuj Chettiar", 31, "Male", "Product Development", 2012, 35700.0));

        //stream from the employeeList
        /*Stream<Latest> a = employeeList.stream();
        a.forEach(System.out::println);*/

        //filter employees who belong to the "HR" department
        /*List<Latest> b = employeeList.stream().filter(e->e.getDepartment().equals("HR")).collect(Collectors.toList());
        System.out.println(b);*/

        //employees count who belong to the "HR" department
        /*long c = employeeList.stream().filter(e->e.getDepartment().equals("HR")).count();
        System.out.println(c);*/

        //map the employee names to uppercase
        /*List<String> d = employeeList.stream().map(e->e.getName().toUpperCase()).collect(Collectors.toList());
        System.out.println(d);*/

        //filter employees name with a salary greater than 20000.0?
        /*System.out.println(employeeList.stream().filter(e->e.getSalary()>20000).map(e->e.getName()).collect(Collectors.toList()));*/

        //Filter employees who joined after the year 2014
        /*List<Latest> f = employeeList.stream().filter(e->e.getYearOfJoining()>2014).collect(Collectors.toList());
        System.out.println(f);*/

        //Retrieve a stream of female employees
        /*Stream<Latest> g = employeeList.stream().filter(e->e.getGender().equals("Female"));
        g.forEach(System.out::println);*/

        /*List<Integer> h = employeeList.stream().map(e->e.getAge()*e.getAge()).collect(Collectors.toList());
        System.out.println(h);*/

        //Extract a stream of employee IDs
        /*Stream<Integer> i = employeeList.stream().map(e->e.getId());
        i.forEach(System.out::println);*/

        //Map where department is the key and a list of employees in that department is the value
        Map<String,List<Latest>> j = employeeList.stream().collect(Collectors.groupingBy(e->e.getDepartment()));
        System.out.println(j);

        //Calculate the total salary of all employees using the collect method
        double k = employeeList.stream().map(Latest::getSalary).reduce((a,b)->a+b).get();
        System.out.println(k);

        double l = employeeList.stream().collect(Collectors.summingDouble(Latest::getSalary));
        System.out.println(l);

        double c = employeeList.stream().mapToDouble(Latest::getSalary).sum();
        System.out.println("New" + c);

        //Each department employees count
        Map<String,Long> m = employeeList.stream().collect(Collectors.groupingBy(Latest::getDepartment,Collectors.counting()));
        System.out.println(m);

        //Partition employees into two groups: those earning more than 25000.0 and others
        Map<Boolean,List<Latest>> emp = employeeList.stream().collect(Collectors.partitioningBy(e->e.getSalary()>25000.0));
        List<Latest> n = emp.get(true);
        List<Latest> o = emp.get(false);
        List<Double> p = n.stream().map(e->e.getSalary()).collect(Collectors.toList());
        System.out.println(p);
        System.out.println(o);

        //Group employees by department and then by gender using groupingBy
        Map<String,Map<String,List<Latest>>> q = employeeList.stream().collect(Collectors.groupingBy(Latest::getDepartment,Collectors.groupingBy(Latest::getGender)));
        System.out.println(q);

        //Find the highest salary using the reduce operation.
        double r = employeeList.stream().mapToDouble(Latest::getSalary).max().getAsDouble();
        System.out.println(r);

        Latest s = employeeList.stream().max(Comparator.comparingDouble(Latest::getSalary)).get();
        System.out.println(s.salary);

        Latest t = employeeList.stream().reduce(BinaryOperator.maxBy(Comparator.comparingDouble(Latest::getSalary))).get();
        System.out.println(t.getSalary());

        Double u = employeeList.stream().mapToDouble(Latest::getSalary).reduce(Double::max).getAsDouble();
        System.out.println("u"+u);

        Latest v = employeeList.stream().collect(Collectors.maxBy(Comparator.comparingDouble(Latest::getSalary))).get();
        System.out.println(v.getSalary());

        Latest x = Collections.max(employeeList, Comparator.comparingDouble(Latest::getSalary));
        System.out.println(x.getSalary());
        //Calculate the sum of ages using the reduce operation.
        Integer w = employeeList.stream().map(Latest::getAge).reduce((a,b)->a+b).get();
        System.out.println(w);

        //Concatenate all employee names into a single string using the reduce operation.
        String y = employeeList.stream().map(Latest::getName).reduce((a,b)-> a+b).get();
        System.out.println(y);

        //Check if there is any employee in the "Sales And Marketing" department.
        Optional<String> z = employeeList.stream().filter(e->e.getDepartment().equals("Sales And Marketing")).map(Latest::getName).findAny();
        z.ifPresent(System.out::println);

        //Find the employee with the highest year of joining.
        Latest ab = employeeList.stream().min(Comparator.comparingInt(Latest::getYearOfJoining)).get();
        System.out.println(ab.getYearOfJoining());

        //Check if all employees are older than 21.
        List<String> abc = employeeList.stream().filter(e->e.getAge()>21).map(Latest::getName).collect(Collectors.toList());
        System.out.println(abc);

        //Sort employees by their age in ascending order
        List<Integer> bc = employeeList.stream().map(Latest::getAge).sorted().collect(Collectors.toList());
        System.out.println(bc);

        //Sort employees by their age in descending order
        List<Integer> cd =employeeList.stream().map(Latest::getAge).sorted((o1, o2) -> o2.compareTo(o1)).collect(Collectors.toList());
        System.out.println(cd);
        List<Latest> ed =employeeList.stream().sorted(Comparator.comparingInt(Latest::getAge)).collect(Collectors.toList());
        System.out.println(ed);

        //Sort employees first by department and then by age
        List<Latest> sortedEmployees = employeeList.stream().sorted(Comparator.comparing(Latest::getDepartment)
                        .thenComparing(Comparator.comparingInt(Latest::getAge))).collect(Collectors.toList());

        //Calculate the average salary using mapToDouble and average.
        double ef = employeeList.stream().mapToDouble(Latest::getSalary).average().getAsDouble();
        System.out.println(ef);

        //Find the sum of salaries using mapToDouble and sum
        double fg = employeeList.stream().mapToDouble(Latest::getSalary).sum();
        System.out.println(fg);

        //Create an IntStream of employee ages and find the maximum age.
        // Create an IntStream of employee ages
        IntStream ageStream = employeeList.stream().mapToInt(Latest::getAge);

        // Find the maximum age
        int maxAge = ageStream.max().getAsInt();

        System.out.println("Maximum Age: " + maxAge);

        //Flatten a stream of lists of employees into a single stream.
        /*List<Latest> flattenedList = employeeList.stream()
                .flatMap(List::stream)
                .collect(Collectors.toList());*/

        Double total = employeeList.stream().map(Latest::getSalary).reduce((a,b)->a+b).get();
        System.out.println("Total"+total);

        double sal = employeeList.stream().mapToDouble(Latest::getSalary).max().getAsDouble();
        System.out.println(sal);

        Latest salary = employeeList.stream().max(Comparator.comparingDouble(Latest::getSalary)).get();
        System.out.println(salary.getSalary());
        //Latest sa = employeeList.stream().max((o1,o2)->o1.getSalary()-o2.getSalary()).get();
        //System.out.println(sa.getSalary());
        Latest ag = employeeList.stream().max((o1, o2) -> o1.getAge()-o2.getAge()).get();
        System.out.println(ag.getAge());
        Integer bge = employeeList.stream().map(Latest::getAge).max((o1, o2) -> o1.compareTo(o2)).get();
        System.out.println(bge);

        Latest sm = employeeList.stream().collect(Collectors.maxBy(Comparator.comparingDouble(Latest::getSalary))).get();
        System.out.println("M " + sm.getSalary());

        String pu = employeeList.stream().map(Latest::getName).collect(Collectors.joining("-"));
        System.out.println(pu);

        List<Integer> ages = employeeList.stream().map(Latest::getAge).sorted(((o1, o2) -> o2.compareTo(o1))).collect(Collectors.toList());
        System.out.println(ages);

        System.out.println(employeeList.stream().sorted(Comparator.comparingInt(Latest::getAge)).collect(Collectors.toList()));

        Map<String,Double> po = employeeList.stream().collect(Collectors.groupingBy(Latest::getName,Collectors.averagingDouble(Latest::getSalary)));
        System.out.println(po);
    }
}
