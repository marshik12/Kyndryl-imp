package com.demo.streamApi;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CountingFrequencyGroupingBy {
    public static void main(String[] args) {
        List<Integer> ls = Arrays.asList(5, 13, 4, 21, 13, 27, 2, 59, 59, 34);
        Map<Integer,Long> map = ls.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()
                )
        );
        System.out.println(map);


    }
}
