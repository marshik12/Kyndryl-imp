package com.demo.customKey;

import java.util.HashMap;
import java.util.Map;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class CustomObjectAsKeyHashMap {
    public static void main(String[] args) {
        Student s1 = new Student(101,"Rahul");
        Student s2 = new Student(102,"Rahul");
        Student s3 = new Student(103,"Rahul");

        HashMap<Student,String> map = new HashMap<>();
        map.put(s1,"Student1");
        map.put(s2,"Student2");
        map.put(s3,"Student3");

        for(Map.Entry<Student,String> m:map.entrySet()){
            System.out.println(m.getKey()+"=="+m.getValue());
    }
    }
}