package com.demo.flatmap;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class EmployeeCitiesFlatMap {
    public static void main(String[] args) {

        List<String> city1 = new ArrayList<>();
        city1.add("Pune");
        city1.add("Mumbai");
        city1.add("Noida");
        city1.add("Bangalore");

        Employee e1 = new Employee(1,"Rahul",city1);

        List<String> city2 = new ArrayList<>();
        city2.add("Pune");
        city2.add("Nagpur");
        city2.add("Indore");

        Employee e2 = new Employee(2,"Raghav",city2);

        List<String> city3 = new ArrayList<>();
        city3.add("Pune");
        city3.add("Bangalore");

        Employee e3 = new Employee(3,"Rajeev",city3);

        List<Employee> employeeList = new ArrayList<Employee>();
        employeeList.add(e1);
        employeeList.add(e2);
        employeeList.add(e3);

        System.out.println(employeeList);


        List<Integer> ids = employeeList.stream().map(emp -> emp.getId()).collect(Collectors.toList());
        System.out.println(ids);

        Set<List<String>> citiesWorkedIn = employeeList.stream().map(emp -> emp.getCitiesWorkedIn()).collect(Collectors.toSet());
        System.out.println(citiesWorkedIn);

        //For each single employees there are multiple cities worked in
        Set<String> citiesWorkedInFlattened = employeeList.stream().flatMap(emp -> emp.getCitiesWorkedIn().stream()).collect(Collectors.toSet());
        System.out.println(citiesWorkedInFlattened);

    }
}
