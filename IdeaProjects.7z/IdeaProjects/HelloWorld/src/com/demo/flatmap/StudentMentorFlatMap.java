package com.demo.flatmap;

import java.util.ArrayList;
import java.util.List;

public class StudentMentorFlatMap {
    public static void main(String[] args) {

        Mentor m1 = new Mentor(1,"Ramesh");
        Mentor m2 = new Mentor(2,"Peter");
        Mentor m3 = new Mentor(3,"John");
        Mentor m4 = new Mentor(4,"Raghav");

        List<Mentor> mentorList = new ArrayList<>();
        mentorList.add(m1);
        mentorList.add(m4);

        List<Mentor> mentorList1 = new ArrayList<>();
        mentorList1.add(m2);
        mentorList1.add(m3);

        List<Mentor> mentorList2 = new ArrayList<>();
        mentorList2.add(m2);


        List<Student> student = new ArrayList<>();
        student.add(new Student(10,"s1",mentorList));
        student.add(new Student(11,"s2",mentorList1));
        student.add(new Student(12,"s3",mentorList2));



       student.stream().map(s->s.getMentor()).forEach(System.out::println);
       List<Mentor> men = student.stream().flatMap(s->s.getMentor().stream()).toList();
       //men.forEach(System.out::println);

        men.stream().filter(m->m.getMentorName().startsWith("Ra")).forEach(System.out::println);
    }
}
