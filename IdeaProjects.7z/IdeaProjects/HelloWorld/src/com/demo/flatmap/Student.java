package com.demo.flatmap;

import java.util.List;
import java.util.Objects;

public class Student {
    int studId;
    String studName;

    List<Mentor> mentor;

    public Student(int studId, String studName, List<Mentor> mentor) {
        this.studId = studId;
        this.studName = studName;
        this.mentor = mentor;
    }



    public List<Mentor> getMentor() {
        return mentor;
    }

    public void setMentor(List<Mentor> mentor) {
        this.mentor = mentor;
    }

    public Student(int studId, String studName) {
        this.studId = studId;
        this.studName = studName;
    }

    public int getStudId() {
        return studId;
    }

    public String getStudName() {
        return studName;
    }

    public void setStudId(int studId) {
        this.studId = studId;
    }

    public void setStudName(String studName) {
        this.studName = studName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Student student = (Student) o;
        return studId == student.studId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(studId);
    }

    @Override
    public String toString() {
        return "Student{" +
                "studId=" + studId +
                ", studName='" + studName + '\'' +
                '}';
    }
}
