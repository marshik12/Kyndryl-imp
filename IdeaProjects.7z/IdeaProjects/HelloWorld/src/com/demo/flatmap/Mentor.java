package com.demo.flatmap;

public class Mentor {
    int mentorId;
    String mentorName;

    public Mentor(int mentorId) {
        this.mentorId = mentorId;
    }

    public Mentor(int mentorId, String mentorName) {
        this.mentorId = mentorId;
        this.mentorName = mentorName;
    }

    public int getMentorId() {
        return mentorId;
    }

    @Override
    public String toString() {
        return "Mentor{" +
                "mentorId=" + mentorId +
                ", mentorName=" + mentorName +
                '}';
    }

    public String getMentorName() {
        return mentorName;
    }

    public void setMentorId(int mentorId) {
        this.mentorId = mentorId;
    }

    public void setMentorName(String mentorName) {
        this.mentorName = mentorName;
    }


}
