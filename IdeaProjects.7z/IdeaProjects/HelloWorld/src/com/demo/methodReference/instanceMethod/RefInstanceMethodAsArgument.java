package com.demo.methodReference.instanceMethod;

interface StringFunction{
    String function(String str);
}
class MyStringOps {
    String reverse(String s){
        String result = "";
        int i;
        for (i=s.length()-1;i>=0;i--){
            result += s.charAt(i);
        }
        return result;
    }
}
public class RefInstanceMethodAsArgument {
    static String stringOp(StringFunction sf, String s){
        return sf.function(s);
    }

    public static void main(String[] args) {
        MyStringOps strOps = new MyStringOps();
        String in = "Instance Method";
        String out = stringOp(strOps::reverse,in);
        System.out.println(out);
    }

}
