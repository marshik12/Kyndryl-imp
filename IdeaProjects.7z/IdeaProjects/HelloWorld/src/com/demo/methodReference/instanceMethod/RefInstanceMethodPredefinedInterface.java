package com.demo.methodReference.instanceMethod;

import java.util.function.BiFunction;

class Arthimetic{
    public int add(int a,int b){
        return a+b;
    }
}
public class RefInstanceMethodPredefinedInterface {
    public static void main(String[] args) {
        BiFunction<Integer,Integer,Integer> adder = new Arthimetic()::add;
        int result = adder.apply(10,20);
        System.out.println(result);
    }
}
