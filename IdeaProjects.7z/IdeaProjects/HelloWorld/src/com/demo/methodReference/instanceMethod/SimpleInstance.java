package com.demo.methodReference.instanceMethod;

import java.util.Arrays;
import java.util.function.Function;

@FunctionalInterface
interface Printable{
    void print(String msg);
}
public class SimpleInstance {
    public void display(String msg){
        msg = msg.toUpperCase();
        System.out.println(msg);
    }

    public static void main(String[] args) {
        //Lambda Expression
        SimpleInstance instance = new SimpleInstance();
        Printable printable = (msg) -> instance.display(msg);
        printable.print("Hello World");

        //Method Reference through instance method
        SimpleInstance instanceRef = new SimpleInstance();
        Printable printableRef = instanceRef::display;
        printableRef.print("Hello World");

        //Instance method of an arbitrary object
        Function<String,String> stringFunction = String::toLowerCase;
        System.out.println(stringFunction.apply("Java"));

        String [] strArray = {"A","E","I","O","U","a","e","i","o","u"};
        //Using Lambda
        Arrays.sort(strArray,(s1,s2) -> s1.compareToIgnoreCase(s2));
        //Using method reference
        Arrays.sort(strArray,String::compareToIgnoreCase);
        System.out.println(strArray);
    }
}
