package com.demo.methodReference.Constructor;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Function;

public class SimpleConstructor {
    public static void main(String[] args) {
        List<String> fruits = new ArrayList<>();
        fruits.add("Banana");
        fruits.add("apple");
        fruits.add("mango");
        fruits.add("Watermelon");
        fruits.add("apple");

        //Using Constructor
        Function<List<String>, Set<String>> setFunction = (fruitsList) -> new HashSet<>(fruitsList);
        System.out.println(setFunction.apply(fruits));

        //Using method Reference
        Function<List<String>, Set<String>> setFunctionRef = HashSet::new;
        System.out.println(setFunctionRef.apply(fruits));
    }

}
