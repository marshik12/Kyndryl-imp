package com.demo.methodReference.Constructor;

interface Messageble{
    Message getMessage(String msg);
}
class Message{
    Message(String msg){
        System.out.println(msg);
    }
}
public class RefConstructorSimple {
    public static void main(String[] args) {
        Messageble hello = Message::new;
        hello.getMessage("Hello World");
    }
}
