package com.demo.methodReference.staticMethod;

import java.util.function.Function;

//Class::staticMethodName
public class simpleStatic {
    public static void main(String[] args) {
        //Lambda Expression
        Function<Integer,Double> funcLambda = (n) -> Math.sqrt(n);
        System.out.println(funcLambda.apply(4));

        //Method Reference through static method
        Function<Integer,Double> funcMethodRef = Math::sqrt;
        System.out.println(funcMethodRef.apply(4));
    }


}
