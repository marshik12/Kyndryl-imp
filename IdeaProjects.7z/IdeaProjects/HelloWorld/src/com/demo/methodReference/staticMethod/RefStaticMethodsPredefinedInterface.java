package com.demo.methodReference.staticMethod;

import java.util.function.BiFunction;

//Class::methodName
class Arithmetic{
    public static int add(int a, int b){
        return a+b;
    }
}
public class RefStaticMethodsPredefinedInterface {
    public static void main(String[] args) {
        BiFunction<Integer,Integer,Integer> adder = Arithmetic::add;
        int result = adder.apply(10,20);
        System.out.println(result);
    }
}
