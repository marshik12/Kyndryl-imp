package com.demo.FunctionalInterface;

import java.util.function.Function;


//Represents a function that accepts one argument and produces a result.
//Type parameters:
//<T> – the type of the input to the function <R> – the type of the result of the function
//Params:
//        t – the function argument
//        Returns: the function result
//public interface Function<T,R> {
//R apply(T t);
//}
class FunctionImpl implements Function<String,Integer>{

    @Override
    public Integer apply(String s) {
        return s.length();
    }
}
public class FunctionInterface {
    public static void main(String[] args) {
        Function<String,Integer> function = new FunctionImpl();
        System.out.println(function.apply("Ramesh"));

        Function<String,Integer> lambda = (s) -> s.length();
        System.out.println(function.apply("Suresh"));
    }
}
