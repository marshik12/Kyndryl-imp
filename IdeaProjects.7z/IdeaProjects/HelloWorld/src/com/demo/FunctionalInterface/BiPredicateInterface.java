package com.demo.FunctionalInterface;

import java.util.function.BiPredicate;

public class BiPredicateInterface {
    public static void main(String[] args) {
        BiPredicate<Integer,Integer> isSumEven = (n1,n2) -> (n1+n2)%2 ==0;
        System.out.println(isSumEven.test(3,5));
    }
}
