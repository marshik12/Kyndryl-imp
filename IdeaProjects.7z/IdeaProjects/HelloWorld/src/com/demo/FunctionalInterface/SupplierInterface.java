package com.demo.FunctionalInterface;

import java.time.LocalDateTime;
import java.util.function.Supplier;

//Represents a supplier of results
//public interface Supplier<T> {
//Type parameters:
//<T> – the type of results supplied by this supplier
//     * Gets a result.
//     * @return a result
//    T get();
//}
class SupplierImpl implements Supplier<LocalDateTime>{

    @Override
    public LocalDateTime get() {
        return LocalDateTime.now();
    }
}
public class SupplierInterface {
    public static void main(String[] args) {
        Supplier<LocalDateTime> supplier = new SupplierImpl();
        System.out.println(supplier.get());
    }
}
