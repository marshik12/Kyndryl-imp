package com.demo.FunctionalInterface;

import java.util.function.Consumer;

//Represents an operation that accepts a single input argument and returns no result
//Type parameters:
//<T> – the type of the input to the operation
//Params:
//        t – the input argument
//public interface Consumer<T> {
//void accept(T t);
//}
class ConsumerImpl implements Consumer<String> {

    @Override
    public void accept(String input) {
        System.out.println(input);
    }
}
public class ConsumerInterface {
    public static void main(String[] args) {
        Consumer<String> consumer = new ConsumerImpl();
        consumer.accept("Hello World!");

        Consumer<String> consumer1 = new ConsumerImpl();
        consumer1.accept("Hello guys!");
    }
}
