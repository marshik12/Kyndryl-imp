package com.demo.FunctionalInterface;

import java.util.Arrays;
import java.util.List;
import java.util.function.BiFunction;


//public interface BiFunction<T, U, R> {

    /**
     * Applies this function to the given arguments.
     *
     * @param t the first function argument
     * @param u the second function argument
     * @return the function result
     */
 //   R apply(T t, U u);
//        Type parameters:
//<T> – the type of the first argument to the function
// <U> – the type of the second argument to the function
// <R> – the type of the result of the function
public class BiFunctionProduct {
    public static void main(String[] args) {
        List<Integer> n1 = Arrays.asList(1,2,3);
        List<Integer> n2 = Arrays.asList(4,5,6);

        //Define a BiFunction to calculate the product of two integers
        BiFunction<Integer,Integer,Integer> productFunction = (a,b) -> a*b;
        List<Integer> products = n1.stream().flatMap(num1 -> n2.stream().map(num2 -> productFunction.apply(num1,num2))).toList();
        System.out.println(products);
    }
}
