package com.demo.FunctionalInterface;

import java.util.function.BiConsumer;

//Represents an operation that accepts two input arguments and returns no result
//Type parameters:
//<T> – the type of the first argument to the operation
// <U> – the type of the second argument to the operation
//public interface BiConsumer<T, U> {

    /*
     * Performs this operation on the given arguments.
     *
     * @param t the first input argument
     * @param u the second input argument
     */
 //   void accept(T t, U u);

public class BiConsumerInterface {
    public static void main(String[] args) {
        BiConsumer<String,String> biConsumer = (s1,s2) -> {
            String result = s1+s2;
            System.out.println(result);
        };
        biConsumer.accept("Hello","World!");
    }

}
