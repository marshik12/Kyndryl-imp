package com.demo.FunctionalInterface;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

//Represents a predicate (boolean-valued function) of two arguments.
// Type parameters:
//<T> – the type of the first argument to the predicate
// <U> – the type of the second argument the predicate
//Params:
//t – the first input argument u – the second input argument
//Returns:
//true if the input arguments match the predicate, otherwise false


public class PredicateStream {
    public static void main(String[] args) {
        List<Integer> num = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
        Predicate<Integer> isEven = n -> n%2 == 0;

        List<Integer> even = num.stream().filter(isEven).collect(Collectors.toList());
        even.forEach(System.out::println);
    }
}
