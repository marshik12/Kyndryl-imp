package com.demo.customHashMap;

import java.util.HashMap;

public class NewHashMap{
    public static void main(String[] args) {
        HashMapEx<String,Integer> map = new HashMapEx<>();
        //Put value into map
        map.put("Raghav", 1);
        map.put("Rahul",2);
        map.put("Rajeev",3);

        //Get values from map
        System.out.println(map.get("Raghav"));
        System.out.println(map.get("Rahul"));
        System.out.println(map.get("Rajeev"));
        System.out.println(map.get("Ramesh"));
    }
}
