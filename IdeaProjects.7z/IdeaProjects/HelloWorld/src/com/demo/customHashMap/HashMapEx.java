package com.demo.customHashMap;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

public class HashMapEx<K,V> {
    private static final int DEFAULT_CAPACITY = 16;
    private LinkedList<Entry<K,V>>[] buckets;
    private int capacity;

    public HashMapEx(){
        this(DEFAULT_CAPACITY);
    }
    public HashMapEx(int initialCapacity){
        this.capacity = initialCapacity;
        this.buckets = new LinkedList[capacity];
        for (int i =0;i<capacity;i++){
            buckets[i] = new LinkedList<>();
        }
    }
    public void put(K key, V value){
        int index = getIndex(key);
        LinkedList<Entry<K,V>> bucket = buckets[index];

        //Check if the key already exists in the bucket
        for(Entry<K,V> entry : bucket){
            if(entry.key.equals(key)){
                entry.value = value; //Update the existing entry
                return;
            }
        }
        //Add a new entry to the bucket
        bucket.add(new Entry<>(key,value));
    }
    public V get(K key){
        int index = getIndex(key);
        LinkedList<Entry<K,V>> bucket = buckets[index];
        //Find the entry with the given key in the bucket
        for (Entry<K,V> entry : bucket){
            if(entry.key.equals(key)){
                return entry.value; //Return the value if found
            }
        }
        return null; //Key not found
    }
    private int getIndex(K key){
        int hashCode = key.hashCode();
        return Math.abs(hashCode % capacity);
    }

    private static class Entry<K,V>{
        K key;
        V value;
        Entry(K key, V value){
            this.key = key;
            this.value = value;
        }
    }
}

