import java.util.concurrent.*;

public class CompletableFutureExample {
    public static void main(String[] args) throws InterruptedException, ExecutionException {
       /* ExecutorService executor = Executors.newFixedThreadPool(4);

        // Using CompletableFuture
        CompletableFuture<Integer> completableFuture = CompletableFuture.supplyAsync(() -> {
            // Perform some computation
            return 42;
        }, executor);

        // Wait for the result
        int result = completableFuture.get();
        System.out.println("Result using CompletableFuture: " + result);

        // Shutdown the executor
        executor.shutdown();*/
        ExecutorService executor = Executors.newFixedThreadPool(4);

        CompletableFuture<Integer> futureA = CompletableFuture.supplyAsync(() -> {            // Perform some computation
             return 42;
        }, executor);
        CompletableFuture<Integer> futureB = CompletableFuture.supplyAsync(() -> {            // Perform some computation
             return 10;
        }, executor);
        CompletableFuture<Integer> futureC = futureA.thenCombineAsync(futureB, (a, b) -> {            // Perform some computation
            return a - b;
        }, executor);

        int result = futureC.get();
        System.out.println("Result using CompletableFuture: " + result);

        executor.shutdown();
    }
}