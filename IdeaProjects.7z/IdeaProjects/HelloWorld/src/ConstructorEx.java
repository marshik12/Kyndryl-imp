class A{
    public A(String msg) {
        System.out.println("A");
    }
}
class B extends A{
    public B() {
        super("Hello");
        System.out.println("B");
    }
}
public class ConstructorEx {
    public static void main(String[] args) {
        A a = new A("Hello");

    }

}
