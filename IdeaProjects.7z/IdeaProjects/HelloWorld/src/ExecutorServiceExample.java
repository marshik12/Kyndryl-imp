import java.util.concurrent.*;

public class ExecutorServiceExample {

    public static void main(String[] args) throws ExecutionException, InterruptedException {
        ExecutorService executorService = Executors.newFixedThreadPool(10);
        executorService.execute(new Runnable() {

            @Override
            public void run() {
                System.out.println("ExecutorService");

            }
        });
        Callable<Integer> callable = () -> {return 2;};
        Future<Integer> future = executorService.submit(callable);
        int f = future.get();
        System.out.println(f);
        executorService.shutdown();
    }

}
