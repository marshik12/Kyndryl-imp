package com.test;

// aaabbcab
//3a2b1c1a1b
public class Test2 {
    public static void main(String[] args) {
        String str = "a?a.ab.b?cab";
        String s = " ";
        char ch[] = str.toCharArray();
        int cnt = 1;
        for (int i = 0; i < ch.length; i++) {
            if (ch[i] >= 'a' && ch[i] <= 'z') {
                s = s + ch[i];
            }
        }
        String st = s.trim();
        for(int j =1; j <= st.length();j++){
            char a = (j < st.length()) ? st.charAt(j) : 0;
            char b = st.charAt(j-1);

            if(a == b){
                cnt ++;
            }else{
                if(cnt != 1) {
                    char c = st.charAt(j-1);
                    System.out.println(cnt + " " + c);
                    cnt = 1;
                }else{
                    char c = st.charAt(j-1);
                    System.out.println(cnt + " " + c);
                }

            }
        }
    }
}
