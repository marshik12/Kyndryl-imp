package com.test;
//Output = 3a2b1c1a1b
public class Test {
    public static void main(String[] args) {
        //String str = "a?a.ab.b?cab";
        String str = "aaabbcab";
        int cnt = 1;

        for(int i=0;i<str.length();i++){
            for(int j=i+1;j<str.length();j++){
                if(str.charAt(i) == str.charAt(j)){
                    cnt++;
                }else {
                    System.out.println(cnt + str.charAt(i));
                    break;
                }
            }
        }
    }
}
