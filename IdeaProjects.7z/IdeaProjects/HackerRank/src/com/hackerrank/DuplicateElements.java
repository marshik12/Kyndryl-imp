package com.hackerrank;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class DuplicateElements {
    public static void main(String[] args) {
        Integer a[] = {2,3,4,2,5,6,7,6};
        List<Integer> ls = Arrays.asList(a);
        Set<Integer> set = new HashSet<>();
        List<Integer> me = ls.stream().filter(s->!set.add(s)).collect(Collectors.toList());
        System.out.println(me);
    }
}
