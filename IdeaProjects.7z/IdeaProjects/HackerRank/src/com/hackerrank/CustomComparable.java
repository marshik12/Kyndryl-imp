package com.hackerrank;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CustomComparable implements Comparable<CustomComparable> {

    private int id;
    private String name;
    private int age;

    public CustomComparable(int id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public int compareTo(CustomComparable o) {
        if(age==o.age) {
            return 0;
        }
        else if (age<o.age) {
            return 1;
        }else{
            return -1;
        }
    }

    public static void main(String[] args) {
        List<CustomComparable> al = new ArrayList<>();
        al.add(new CustomComparable(2, "Ram", 25));
        al.add(new CustomComparable(1, "Mahesh", 20));

        for (CustomComparable c : al) {
            System.out.println(c.getId()+c.getName()+c.getAge());
        }
    }
}