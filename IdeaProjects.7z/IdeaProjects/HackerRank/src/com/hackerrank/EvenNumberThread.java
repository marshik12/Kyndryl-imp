package com.hackerrank;

public class EvenNumberThread extends Thread{
    private EvenOddNumber obj;

    public EvenNumberThread(EvenOddNumber obj) {
        this.obj = obj;
    }
    @Override
    public void run(){
        obj.generateEvenNumbers();
    }
}
