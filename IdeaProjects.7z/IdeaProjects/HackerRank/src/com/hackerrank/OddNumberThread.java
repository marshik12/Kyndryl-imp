package com.hackerrank;

public class OddNumberThread extends Thread{
    private EvenOddNumber obj;

    public OddNumberThread(EvenOddNumber obj) {
        this.obj = obj;
    }

    @Override
    public void run(){
        obj.generateOddNumbers();
    }
}
