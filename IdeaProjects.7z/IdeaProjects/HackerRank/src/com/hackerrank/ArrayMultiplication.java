package com.hackerrank;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class ArrayMultiplication {
    public static void main(String[] args) {
        Integer[] p = {1,2,3,4,5};
        List<Integer> list = Arrays.asList(p);
        Optional<Integer> mul = list.stream().reduce((a, b) -> a*b);
        if(mul.isPresent()){
            System.out.println(mul.get());
        }
    }
}
