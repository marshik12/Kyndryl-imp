package com.hackerrank;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SingleSorting {
    public static void main(String[] args) {
        List<StudentComparable> stu = new ArrayList<>();
        stu.add(new StudentComparable(3,"Ramesh"));
        stu.add(new StudentComparable(2,"Rajesh"));
        stu.add(new StudentComparable(1,"Ragu"));
        System.out.println(stu);
        Collections.sort(stu);
        System.out.println(stu);

    }
}
