package com.hackerrank;

import java.util.HashMap;
import java.util.Map;

public class WordCount {
    public static void main(String[] args) {
        String str = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum";
        String s[] = str.split("[\s,.]");
        Map<String,Integer> map = new HashMap<>();
        for(String s1:s){
            if(map.containsKey(s1)){
                map.put(s1,map.get(s1)+1);
            }else{
                map.put(s1,1);
            }
        }
        for(Map.Entry<String,Integer> m:map.entrySet()){
            System.out.println("Key " + m.getKey() + "Value " + m.getValue() );
        }
    }

}
