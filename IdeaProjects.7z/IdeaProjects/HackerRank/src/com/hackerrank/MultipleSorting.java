package com.hackerrank;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MultipleSorting {
    public static void main(String[] args) {
        List<StudentComparator> ls = new ArrayList<>();
        ls.add(new StudentComparator(3,"Ramesh"));
        ls.add(new StudentComparator(2,"Suresh"));
        ls.add(new StudentComparator(1,"Raju"));

        System.out.println(ls);
        Collections.sort(ls,new NameComparator());
        System.out.println(ls);

        List<StudentComparator> ls1 = new ArrayList<>(ls);
        Collections.sort(ls1,new IdComparator());
        System.out.println(ls1);
    }
}
