package com.hackerrank;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Stu {
    public static void main(String[] args) {
        Student s1 = new Student("Ram",10);
        Student s2 = new Student("Sam",11);
        Student s3 = new Student("Mam",12);
        Student s4 = new Student("Dam",13);

        List<Student> st = new ArrayList<>();
        st.add(s1);
        st.add(s2);
        st.add(s3);
        st.add(s4);

         System.out.println(st.stream().map(Student::getMarks).sorted((o1, o2) -> o2.compareTo(o1)).skip(1).findFirst().get());
    }
}
