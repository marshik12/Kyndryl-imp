package AccessMember.p2;

public class OtherPackage {
    OtherPackage(){
        AccessMember.p1.Protection p = new AccessMember.p1.Protection();
        System.out.println("other package constructor");

        //class or package only
        //System.out.println("n = " + p.n);

        //class only
        //System.out.println("n = " + p.n_pri);

        //class,subclass or package only
        //System.out.println("n_pri = " + p.n_pro);

        System.out.println("n_pub = " + p.n_pub);
    }
}
