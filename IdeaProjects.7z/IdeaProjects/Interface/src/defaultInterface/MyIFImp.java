package defaultInterface;

public class MyIFImp implements MyIF{
    public int getNumber() {
        return 100;
    }
}
