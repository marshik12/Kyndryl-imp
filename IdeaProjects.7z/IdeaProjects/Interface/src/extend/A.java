package extend;

interface A {
    void meth1();
    void meth2();
}
