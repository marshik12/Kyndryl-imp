package extend;

interface B extends A{
    void meth3();
}
